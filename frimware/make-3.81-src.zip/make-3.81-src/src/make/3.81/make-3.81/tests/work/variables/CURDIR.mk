all: ; @echo $(CURDIR)
