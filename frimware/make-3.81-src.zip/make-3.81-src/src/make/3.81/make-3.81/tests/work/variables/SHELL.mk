all:;@echo "$(SHELL)"
